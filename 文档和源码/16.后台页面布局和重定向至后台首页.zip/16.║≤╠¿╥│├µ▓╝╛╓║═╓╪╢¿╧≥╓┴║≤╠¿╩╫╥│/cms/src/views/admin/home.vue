<script setup>
    import '@/assets/admin/css/home.css' //导入样式

</script>

<template>
    <div class="dr-home">
        <div class="header">
      
        </div>

        <div class="main">
            <div class="side">

            </div>

            <div class="content">
                
            </div>
        </div>        
    </div>
</template>

<style scoped>

</style>