import { createApp } from 'vue'
import App from './App.vue'

//console.log(import.meta.env) //环境变量

//createApp(App).mount('#app')
const app = createApp(App)
app.mount('#app')