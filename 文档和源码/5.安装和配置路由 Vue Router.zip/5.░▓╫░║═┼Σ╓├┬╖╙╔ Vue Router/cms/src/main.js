import { createApp } from 'vue'
import App from './App.vue'

//路由
import router from './router' //导入路由模块

const app = createApp(App)
app.use(router) //将 Vue Router 插件注册到 Vue 应用中
app.mount('#app')