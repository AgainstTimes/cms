<script setup>
    import { reactive,onMounted } from 'vue'
    import { ElMessage } from 'element-plus'
    import AxiosDR from '@/DRUtils/AxiosDR.js'

    const data = reactive({
        list: []
    })

    //在组件成功挂载到DOM并完成首次渲染后调用
    onMounted(() => {
        AxiosDR.get('/api/adm/list').then(result => {
            //console.log(result)

            if(!result.status){
                ElMessage.error(result.msg)
                return
            }

            data.list = result.data.list
        }).catch(err => {
            console.log("err:", err)
        })
    })
</script>

<template>
    <el-table :data="data.list" border>
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="name" label="名称" />
        <el-table-column prop="email" label="邮箱" />
        <el-table-column prop="remark" label="备注"/>

        <el-table-column label="操作" width="150">
            <template #default="scope">
                <el-button size="small" type="primary">编辑</el-button>
                <el-button size="small">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<style scoped>

</style>