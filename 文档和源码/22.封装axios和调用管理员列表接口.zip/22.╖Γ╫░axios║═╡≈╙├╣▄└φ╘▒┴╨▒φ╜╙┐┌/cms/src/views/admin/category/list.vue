<script setup>

</script>

<template>
    类别管理
</template>

<style scoped>

</style>