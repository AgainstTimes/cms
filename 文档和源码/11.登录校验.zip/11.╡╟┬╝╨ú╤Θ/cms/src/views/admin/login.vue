<script setup>
    import '@/assets/admin/css/login.css' //导入样式
    import { reactive,ref } from 'vue'
    import { User,Lock } from '@element-plus/icons-vue' //图标

    const data = reactive({
        name: '',
        password: '',
    })

    //校验规则
    const rules = {
        name: [
            { required: true, message: '请填写用户名', trigger: 'blur' },
            { min: 2, max: 10, message: '用户名长度限制[ 2 - 10 ]个字符', trigger: 'blur' }
        ],
        password: [
            { required: true, message: '请填写密码', trigger: 'blur' }
        ]
    }

    const elFormRef = ref() //存储 <el-form> 组件实例的引用

    
    //登录
    const login = () => {
        console.log(data)

        elFormRef.value.validate((valid, fields) => { //校验
            //console.log("valid:",valid,"fields:",fields)
            if (!valid) {
                return
            }
        })
    }
</script>

<template>
    <div class="dr-login">
        <el-form :model="data" :rules="rules" ref="elFormRef">
            <div class="title">
                DR_CMS
            </div>

            <el-form-item prop="name">
                <el-input :prefix-icon="User" v-model="data.name" />
            </el-form-item>

            <el-form-item prop="password">
                <el-input :prefix-icon="Lock" show-password v-model="data.password" />
            </el-form-item>

            <el-form-item>
                <el-button type="primary" @click="login">登录</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<style scoped>
    
</style>