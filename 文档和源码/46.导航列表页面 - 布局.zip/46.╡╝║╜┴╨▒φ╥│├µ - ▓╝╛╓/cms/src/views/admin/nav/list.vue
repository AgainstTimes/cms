<script setup>
    import { reactive } from 'vue'

    //数据
    const data = reactive({
        path: [
            { id:'1',parent_id:'0',name:'导航管理'},
        ],
        list: [
            { id:'1',parent_id:'0',name:'导航管理',icon:'Guide',path:'/admin/nav/list?parent_id=0',status:'1',create_time:'2024-04-29 12:00:00'},
            { id:'2',parent_id:'0',name:'类别管理',icon:'Files',path:'/admin/category/list?parent_id=0',status:'1',create_time:'2024-04-29 12:00:58'},
        ]
    })


    const funcFormatDate = (time) => { //func - 格式化日期
        return time.slice(0, 10) //截取前10个字符
    }
</script>

<template>
    <!-- 面包屑 -->
    <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/admin/nav/list', query: { parent_id: 0 } }">
            <el-icon><House /></el-icon>
        </el-breadcrumb-item>
        
        <el-breadcrumb-item v-for="value in data.path" :to="{path:'/admin/nav/list',query:{ parent_id: value.id}}" :key="value.id">
            {{ value.name }}
        </el-breadcrumb-item>
    </el-breadcrumb>

    <!-- 按钮 -->
    <el-button type="primary">添加导航</el-button>

    <!-- 表格 -->
    <el-table :data="data.list" border>
        <el-table-column prop="id" label="ID" width="60" />

        <el-table-column prop="name" label="名称" width="100">
            <template #default="scope">
                <router-link :to="{ path: '/admin/nav/list', query: { parent_id: scope.row.id } }" class="blue">
                    {{ scope.row.name }}
                </router-link>
            </template>
        </el-table-column>

        <el-table-column prop="icon" label="图标" width="60">
            <template #default="scope">
                <el-icon v-if="scope.row.icon"><component :is="scope.row.icon" /></el-icon>
            </template>
        </el-table-column>

        <el-table-column prop="path" label="路径"/>

        <el-table-column prop="status" label="状态" width="60">
            <template #default="scope">
                <span v-if="scope.row.status === '1'" class="green">显示</span>
                <span v-else class="orange">隐藏</span>
            </template>
        </el-table-column>

        <!-- <el-table-column prop="create_time" label="日期" width="180" /> -->
        <el-table-column prop="create_time" label="日期" width="180">
            <template #default="scope">
                {{ funcFormatDate(scope.row.create_time) }}
            </template>
        </el-table-column>

        <el-table-column label="操作" width="150">
            <template #default="scope">
                <el-button size="small" type="primary">编辑</el-button>
                <el-button size="small">删除</el-button>
            </template>
        </el-table-column>
    </el-table>

</template>

<style scoped>

</style>