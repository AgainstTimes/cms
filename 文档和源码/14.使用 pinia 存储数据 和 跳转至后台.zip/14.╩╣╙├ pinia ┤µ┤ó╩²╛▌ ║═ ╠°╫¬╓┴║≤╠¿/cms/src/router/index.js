import { createRouter, createWebHistory } from "vue-router"

const routes = [
    {
        path: "/login", // http://localhost:5173/login
        //component: () => import("../views/admin/login.vue")
        component: () => import("@/views/admin/login.vue")
    },
    {
        path: "/admin", // http://localhost:5173/admin
        component: () => import("@/views/admin/home.vue")
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router