<script setup>
    import '@/assets/admin/css/login.css' //导入样式
    import { reactive } from 'vue'
    import { User,Lock } from '@element-plus/icons-vue' //图标

    const data = reactive({
        name: '',
        password: '',
    })

    //登录
    const login = () => {
        console.log(data)
    }
</script>

<template>
    <div class="dr-login">
        <el-form :model="data">
            <div class="title">
                DR_CMS
            </div>

            <el-form-item>
                <el-input :prefix-icon="User" v-model="data.name" />
            </el-form-item>

            <el-form-item>
                <el-input :prefix-icon="Lock" show-password v-model="data.password" />
            </el-form-item>

            <el-form-item>
                <el-button type="primary" @click="login">登录</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<style scoped>

</style>