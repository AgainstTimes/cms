<script setup>

</script>

<template>
    添加管理员
</template>

<style scoped>

</style>